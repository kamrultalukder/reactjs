import React from 'react';

class DestComponent extends React.Component {
    constructor(props){
        super(props);

        console.log(this.props);
    }

    render() {
        return null;
    }
}

export default DestComponent;